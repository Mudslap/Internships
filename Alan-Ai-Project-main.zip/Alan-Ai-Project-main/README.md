# Alan-Ai-Project
In this repository, there are two main files. The first one is my actual Flagship Project for Alan AI (the finished project). The other project is the code I created for my Youtube tutorial series where people can follow along as I code a replica of my finished project. If you want to access the game code, all you have to do is download the files and then open the files in your perferred HTML, CSS, JS file editor. The editor I used was Brackets.io so you an use that editor as well but any editor should work. 

My Youtube videos to follow along:
https://www.youtube.com/watch?v=un9FuHu_XJ8&list=PLJvQtLU4FCqfj3awDwFTu1CNuL0ZIL7Kz
